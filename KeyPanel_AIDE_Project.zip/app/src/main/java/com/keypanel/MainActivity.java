package com.keypanel;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.*;
import java.net.*;

public class MainActivity extends AppCompatActivity {

    EditText keyInput, nameInput, emailInput;
    TextView resultView;
    String apiBase = "https://your-backend-host.com"; // Replace with hosted URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        keyInput = findViewById(R.id.keyInput);
        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        resultView = findViewById(R.id.resultText);
    }

    public void validateKey(View view) {
        String key = keyInput.getText().toString();
        new Thread(() -> {
            try {
                URL url = new URL(apiBase + "/api/validate");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                os.write(("{"key":"" + key + ""}").getBytes("UTF-8"));
                os.close();
                InputStream in = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line, json = "";
                while ((line = reader.readLine()) != null) json += line;
                JSONObject obj = new JSONObject(json);
                runOnUiThread(() -> resultView.setText(obj.getString("message")));
            } catch (Exception e) {
                runOnUiThread(() -> resultView.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    public void createUser(View view) {
        String name = nameInput.getText().toString();
        String email = emailInput.getText().toString();
        String key = keyInput.getText().toString();
        new Thread(() -> {
            try {
                URL url = new URL(apiBase + "/api/create-user");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                os.write(("{"name":"" + name + "","email":"" + email + "","key":"" + key + ""}").getBytes("UTF-8"));
                os.close();
                InputStream in = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line, json = "";
                while ((line = reader.readLine()) != null) json += line;
                JSONObject obj = new JSONObject(json);
                runOnUiThread(() -> resultView.setText(obj.getString("message")));
            } catch (Exception e) {
                runOnUiThread(() -> resultView.setText("Error: " + e.getMessage()));
            }
        }).start();
    }
}